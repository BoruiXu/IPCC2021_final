#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 2
#SBATCH -n 128
srun ./cp2shm.x ../data
mpirun ./main 0.005  /dev/shm/mydata/ipcc_gauge_24_72  24 24 24 72 24 3 3 36
mpirun ./main 0.005  /dev/shm/mydata/ipcc_gauge_32_64  32 32 32 64 32 16 4 8 
mpirun ./main 0.005  /dev/shm/mydata/ipcc_gauge_48_96  48 48 48 96 48 12 3 48

