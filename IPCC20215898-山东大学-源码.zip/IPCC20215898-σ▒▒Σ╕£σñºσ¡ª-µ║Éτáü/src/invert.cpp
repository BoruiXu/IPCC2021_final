/**
** @file:  invert.cpp
** @brief:
**/

#include "invert.h"
#include "operator_mpi.h"
#include <stdlib.h>
#include <math.h>
#include <iostream>
using namespace std;


void apply_hermiticity(lattice_fermion &src,lattice_fermion &dest)

{


    int subgrid_vol = (src.subgs[0] * src.subgs[1] * src.subgs[2] * src.subgs[3]);
    int subgrid_vol_cb = (subgrid_vol) >> 1;

    for(int i = subgrid_vol_cb;i<subgrid_vol;i++){

        for(int j = 0;j<12;j++){

            if(j<6){
                dest.A[i*12+j] = src.A[i*12+j];
            }
            else{
                dest.A[i*12+j] = src.A[i*12+j]*-1.0;
            }
            
        }
    }




}

int CGinvert(complex<double> *src_p, complex<double> *dest_p, complex<double> *gauge[4],
             const double mass, const int max, const double accuracy, int *subgs, int *site_vec)
{
    lattice_gauge U(gauge, subgs, site_vec);
    lattice_fermion src(src_p, subgs, site_vec);
    lattice_fermion dest(dest_p, subgs, site_vec);
    CGinvert(src, dest, U, mass, max, accuracy);
    return 0;
}

int CGinvert(lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
             const int max, const double accuracy)
{
    int myrank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    lattice_fermion r0(src.subgs, src.site_vec);
    lattice_fermion r1(src.subgs, src.site_vec);
    lattice_fermion q(src.subgs, src.site_vec);
    //lattice_fermion qq(src.subgs, src.site_vec);
    lattice_fermion p(src.subgs, src.site_vec);
    //lattice_fermion Mdb(src.subgs, src.site_vec);
    lattice_fermion tmp(src.subgs, src.site_vec);

	//buffer
    //lattice_fermion buf0(src.subgs, src.site_vec);
    lattice_fermion buf1(src.subgs, src.site_vec);

	complex<double> beta1;
	complex<double> beta2;

    int subgrid_vol = (src.subgs[0] * src.subgs[1] * src.subgs[2] * src.subgs[3])*3*4;
    int subgrid_vol_cb = (subgrid_vol) >> 1;


    complex<double> aphi(0);
    complex<double> beta(0);


    //得到M^dagger src
    // Dslash_test(src, Mdb, U, mass, true);

    Dslash_right(src,tmp,U,mass,false);
    //Dslash_left(tmp,Mdb,U,mass,true, buf0, buf1);
    //Dslash_left(tmp,p,U,mass,true, buf0, buf1);
    Dslash_left(tmp,p,U,mass,true, r1, buf1);
    // apply_hermiticity(tmp,Mdb);

    //猜测的初始解
    // for (int i = 0; i < dest.size; i++) {
    //     dest.A[i] = 1.0 * rand() / RAND_MAX;
    // }
    // dest.A[0] = 1.0;


#ifdef DEBUG
    double src_nr2 = norm_2(src);
    double dest_nr2 = norm_2(dest);
    if (myrank == 0) {
        cout << "|src|^2 = " << src_nr2 << " , |dest|^2 = " << dest_nr2 << endl;
    }
#endif

    //首先计算M dest，再计算M^dagger M dest 得到r0是一个结果（逼近于 M^dagger src）
    // Dslash_test(dest, tmp, U, mass, false);
    // Dslash_test(tmp, r0, U, mass, true);


    //求完之后，r0只计算了奇数部分
    Dslash_left(dest,tmp,U,mass,false, r1, buf1);
    Dslash_left(tmp,r0,U,mass,true, r1, buf1);
    //Dslash_left(dest,tmp,U,mass,false, buf0, buf1);
    //Dslash_left(tmp,r0,U,mass,true, buf0, buf1);

    // apply_hermiticity(tmp,r0);


    //得到两个数值之间的差
    
    // for (int i = 0; i < Mdb.size; i++) {
    //     r0.A[i] = Mdb.A[i] - r0.A[i];
    // }

    //只计算奇数部分的差
    //for (int i = subgrid_vol_cb; i < Mdb.size; i++) {
    //    r0.A[i] = Mdb.A[i] - r0.A[i];
    //}
    for (int i = subgrid_vol_cb; i <p.size; i++) {
        r0.A[i] = p.A[i] - r0.A[i];
    }

    //奇数部分的迭代
    for (int f = 1; f < max; f++) 
    //for (int f = 1; f < 57; f++) 
	{

        //p就是需要更新的梯度？得到p
        if (f == 1) {
            for (int i = subgrid_vol_cb; i < r0.size; i++)
                p.A[i] = r0.A[i];
        } 

        else {
            beta = vector_p_O(r0, r0) / vector_p_O(r1, r1);
			//beta1 = vector_p_O(r0, r0);
			//beta2 = vector_p_O(r1, r1);
			//double c2d2 = 1/(beta2.real() * beta2.real() + beta2.imag() * beta2.imag());
			//beta = complex<double>((beta1.real() * beta2.real() + beta1.imag() * beta2.imag()) * c2d2, 
			//                       (beta1.imag() * beta2.real() - beta1.real() * beta2.imag()) * c2d2);
			#pragma unroll(4)
            for (int i = subgrid_vol_cb; i < r0.size; i++)
                p.A[i] = r0.A[i] + beta * p.A[i];
        }


        // M p 
        //Dslash_left(p, qq, U, mass, false, buf0, buf1);
        //Dslash_left(qq, q, U, mass, true, buf0, buf1);
        //Dslash_left(p, tmp, U, mass, false, buf0, buf1);
        //Dslash_left(tmp, q, U, mass, true, buf0, buf1);
        Dslash_left(p, tmp, U, mass, false, r1, buf1);
        Dslash_left(tmp, q, U, mass, true, r1, buf1);
        // apply_hermiticity(qq,q);

        //得到更新的幅度
        aphi = vector_p_O(r0, r0) / vector_p_O(p, q);

		#pragma unroll(4)
        for (int i = subgrid_vol_cb; i < dest.size; i++)
            //p是迭代算法中的d
            dest.A[i] = dest.A[i] + aphi * p.A[i];

        //记录r0的值在r1中
        //for (int i = subgrid_vol_cb; i < r1.size; i++)
        //    r1.A[i] = r0.A[i];
		double * r1AA = (double *)r1.A;
		double * r0AA = (double *)r0.A;
		//#pragma simd vectorlength(4)
        //for (int i = subgrid_vol_cb * 2; i < r1.size * 2; i++)
        //    r1AA[i] = r0AA[i];


        //误差减小
		#pragma unroll(4)
        for (int i = subgrid_vol_cb; i < r0.size; i++)
            r1.A[i] = r0.A[i] - aphi * q.A[i];
	
		complex<double> * swap = r0.A;
		r0.A = r1.A;
		r1.A = swap;

        //进程之间求和
        double rsd2 = norm_2_O_mpi(r0);
        //开方
        double rsd = sqrt(rsd2);
        if (rsd < accuracy * 3) {
            if (myrank == 0) {
                cout << "CG: " << f << " iterations, convergence residual |r| = " << rsd << endl;
            }
            break;
        }


        
        if (myrank == 0) {
            cout << "CG: " << f << " iter, rsd |r| = " << rsd << endl;
        }

    }

    //重构偶数部分
    Restruct_E(src,dest,dest,U, mass, false);


//     for (int f = 1; f < max; f++) {

//         //p就是需要更新的梯度？得到p
//         if (f == 1) {
//             for (int i = 0; i < r0.size; i++)
//                 p.A[i] = r0.A[i];
//         } 

//         else {
//             beta = vector_p(r0, r0) / vector_p(r1, r1);
//             for (int i = 0; i < r0.size; i++)
//                 p.A[i] = r0.A[i] + beta * p.A[i];
//         }


//         // M p 
//         Dslash_test(p, qq, U, mass, false);
//         Dslash_test(qq, q, U, mass, true);

//         //得到更新的幅度
//         aphi = vector_p(r0, r0) / vector_p(p, q);

//         for (int i = 0; i < dest.size; i++)
//             //p是迭代算法中的d
//             dest.A[i] = dest.A[i] + aphi * p.A[i];

//         //记录r0的值在r1中
//         for (int i = 0; i < r1.size; i++)
//             r1.A[i] = r0.A[i];

//         //误差减小
//         for (int i = 0; i < r0.size; i++)
//             r0.A[i] = r0.A[i] - aphi * q.A[i];

//         //进程之间求和
//         double rsd2 = norm_2(r0);
//         //开方
//         double rsd = sqrt(rsd2);
//         if (rsd < accuracy) {
//             if (myrank == 0) {
//                 cout << "CG: " << f << " iterations, convergence residual |r| = " << rsd << endl;
//             }
//             break;
//         }
// #ifndef VERBOSE_SIMPLE
//         if (myrank == 0) {
//             cout << "CG: " << f << " iter, rsd |r| = " << rsd << endl;
//         }
// #endif
//     }
    return 0;
}

void Dslash(lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
            const bool dagger)
{
    dest.clean();
    lattice_fermion tmp(src.subgs, src.site_vec);
    DslashEE(src, tmp, mass);
    dest = dest + tmp;
    DslashOO(src, tmp, mass);
    dest = dest + tmp;
    Dslashoffd(src, tmp, U, dagger, 0); // cb=0, EO
    dest = dest + tmp;
    Dslashoffd(src, tmp, U, dagger, 1);
    dest = dest + tmp;
}

void Dslash_test(lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
            const bool dagger)
{   
    

    dest.clean();


    lattice_fermion tmp(src.subgs, src.site_vec);

    
    DslashEE_test(src, tmp, mass);
    dest = dest + tmp;

    Dslashoffd_test(src, tmp, U, dagger, 0); // cb=0, EO
    dest = dest + tmp;
    
    
    DslashOO_test(src, tmp, mass);
    dest = dest + tmp;
    
    
    Dslashoffd_test(src, tmp, U, dagger, 1);
    dest = dest + tmp;


}




void Dslash_left(lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
            const bool dagger,
			lattice_fermion &tmp,
			lattice_fermion &tmp2
			)

{

   

    int subgrid_vol = (src.subgs[0] * src.subgs[1] * src.subgs[2] * src.subgs[3]);
    int subgrid_vol_cb = (subgrid_vol) >> 1;
    

    // dest.clean();

    //lattice_fermion tmp(src.subgs, src.site_vec);
    //lattice_fermion tmp2(src.subgs, src.site_vec);


    //DslashOO_test(src, tmp, mass);
    DslashOO_test(src, dest, mass);


    //奇数部分
    //for (int i = subgrid_vol_cb * 3 * 4; i < subgrid_vol * 3 * 4; i++) {
    //    
    //    dest.A[i] = tmp.A[i];
    //}

	double * desAA = (double *)dest.A;
	double * tmpAA = (double *) tmp.A;
    //for (int i = subgrid_vol_cb * 3 * 4 * 2; i < subgrid_vol * 3 * 4 * 2; i++) {
	//	desAA[i] = tmpAA[i];
	//}

    Dslashoffd_test(src, tmp, U, dagger, 0);


    DslashEE1_test(tmp, tmp2, mass);


    Dslashoffd_test(tmp2, tmp, U, dagger, 1);


    //奇数部分的减法
    
    //for (int i = subgrid_vol_cb * 3 * 4; i < subgrid_vol * 3 * 4; i++) {
    //    
    //    dest.A[i] -= tmp.A[i];
    //}
	//
	desAA = (double *)dest.A;
	tmpAA = (double *) tmp.A;
    for (int i = subgrid_vol_cb * 3 * 4 * 2; i < subgrid_vol * 3 * 4 * 2; i++) {
		desAA[i] -= tmpAA[i];
	}



}


void Dslash_right(lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
            const bool dagger)
{
    //计算完成之后数据是奇数部分

    

    // dest.clean();

    lattice_fermion tmp(src.subgs, src.site_vec);
    lattice_fermion tmp2(src.subgs, src.site_vec);


    DslashEE1_test(src, tmp, mass);

    Dslashoffd_test(tmp, tmp2, U, dagger, 1);

    int subgrid_vol = (src.subgs[0] * src.subgs[1] * src.subgs[2] * src.subgs[3]);
    int subgrid_vol_cb = (subgrid_vol) >> 1;
    for (int i = subgrid_vol_cb * 3 * 4; i < subgrid_vol * 3 * 4; i++) {
        
        dest.A[i] = src.A[i]-tmp2.A[i];
    }


}



void Restruct_E(lattice_fermion &b, lattice_fermion &src, lattice_fermion &dest, lattice_gauge &U, const double mass,
            const bool dagger)
{

    

    lattice_fermion tmp(src.subgs, src.site_vec);
    lattice_fermion tmp2(src.subgs, src.site_vec);


    Dslashoffd_test(src, tmp, U, dagger, 0);

    int subgrid_vol = (src.subgs[0] * src.subgs[1] * src.subgs[2] * src.subgs[3]);
    int subgrid_vol_cb = (subgrid_vol) >> 1;
        
    for (int i = 0; i < subgrid_vol_cb * 3 * 4; i++) {
        tmp2.A[i] = b.A[i]-tmp.A[i];
    }

    //DslashEE1_test(tmp2, tmp, mass);
    DslashEE1_test(tmp2, dest, mass);

    //for(int i = 0; i < subgrid_vol_cb * 3 * 4; i++){

    //    dest.A[i] = tmp.A[i];
    //}


}
















