# latticechina

```bash
#compile app 注意load 的先后顺序
cd src
source /public1/soft/modules/module.sh
module load mpi/intel/20.4.3
module load mpi/intel/2018.4
make

代码使用说明：
1、提交代码通过sub.sh方式运行
2、数据的目录写在sub.sh的cp2shm.x 的后面，将数据加载到shm中
3、
